/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1a73e8',
          dark: '#1557b0',
          light: '#e8f0fe'
        },
        success: '#34a853',
        danger: '#ea4335',
        warning: '#fbbc04'
      }
    },
  },
  plugins: [
    require('@tailwindcss/forms')
  ],
}