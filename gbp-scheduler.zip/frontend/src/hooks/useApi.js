import { useQuery, useMutation, useQueryClient } from 'react-query'
import { useAuthStore } from '../store/authStore'

const API_URL = import.meta.env.VITE_API_URL || ''

function useAuthFetch() {
  const { token, logout } = useAuthStore()

  return async (endpoint, options = {}) => {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
        ...options.headers
      }
    })

    if (response.status === 401) {
      logout()
      throw new Error('Unauthorized')
    }

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Something went wrong')
    }

    return response.json()
  }
}

// Businesses
export function useBusinesses() {
  const fetch = useAuthFetch()
  return useQuery('businesses', () => fetch('/api/businesses'))
}

export function useCreateBusiness() {
  const fetch = useAuthFetch()
  const queryClient = useQueryClient()

  return useMutation(
    (data) => fetch('/api/businesses', { method: 'POST', body: JSON.stringify(data) }),
    { onSuccess: () => queryClient.invalidateQueries('businesses') }
  )
}

export function useDeleteBusiness() {
  const fetch = useAuthFetch()
  const queryClient = useQueryClient()

  return useMutation(
    (id) => fetch(`/api/businesses/${id}`, { method: 'DELETE' }),
    { onSuccess: () => queryClient.invalidateQueries('businesses') }
  )
}

// Posts
export function usePosts(status) {
  const fetch = useAuthFetch()
  const url = status ? `/api/posts?status=${status}` : '/api/posts'
  return useQuery(['posts', status], () => fetch(url))
}

export function useCreatePost() {
  const fetch = useAuthFetch()
  const queryClient = useQueryClient()

  return useMutation(
    (data) => fetch('/api/posts', { method: 'POST', body: JSON.stringify(data) }),
    { onSuccess: () => {
      queryClient.invalidateQueries('posts')
      queryClient.invalidateQueries('stats')
    }}
  )
}

export function useUpdatePost() {
  const fetch = useAuthFetch()
  const queryClient = useQueryClient()

  return useMutation(
    ({ id, data }) => fetch(`/api/posts/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    { onSuccess: () => {
      queryClient.invalidateQueries('posts')
      queryClient.invalidateQueries('stats')
    }}
  )
}

export function useDeletePost() {
  const fetch = useAuthFetch()
  const queryClient = useQueryClient()

  return useMutation(
    (id) => fetch(`/api/posts/${id}`, { method: 'DELETE' }),
    { onSuccess: () => {
      queryClient.invalidateQueries('posts')
      queryClient.invalidateQueries('stats')
    }}
  )
}

// Stats
export function useStats() {
  const fetch = useAuthFetch()
  return useQuery('stats', () => fetch('/api/users/stats'))
}
