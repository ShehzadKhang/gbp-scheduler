import { create } from 'zustand'
import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export const useStore = create((set, get) => ({
  // Auth state
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  token: localStorage.getItem('token'),
  isLoading: false,

  // Data state
  businesses: [],
  posts: [],
  stats: null,

  // Auth actions
  login: async (email, password) => {
    set({ isLoading: true })
    try {
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))
      set({ user: data.user, token: data.token, isLoading: false })
      return { success: true }
    } catch (error) {
      set({ isLoading: false })
      return { success: false, error: error.response?.data?.message || 'Login failed' }
    }
  },

  register: async (name, email, password) => {
    set({ isLoading: true })
    try {
      const { data } = await api.post('/auth/register', { name, email, password })
      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))
      set({ user: data.user, token: data.token, isLoading: false })
      return { success: true }
    } catch (error) {
      set({ isLoading: false })
      return { success: false, error: error.response?.data?.message || 'Registration failed' }
    }
  },

  logout: () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    set({ user: null, token: null, businesses: [], posts: [], stats: null })
  },

  // Business actions
  fetchBusinesses: async () => {
    try {
      const { data } = await api.get('/businesses')
      set({ businesses: data })
      return data
    } catch (error) {
      console.error('Fetch businesses error:', error)
      return []
    }
  },

  createBusiness: async (businessData) => {
    try {
      const { data } = await api.post('/businesses', businessData)
      set((state) => ({ businesses: [...state.businesses, data] }))
      return { success: true, data }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to create business' }
    }
  },

  deleteBusiness: async (id) => {
    try {
      await api.delete(`/businesses/${id}`)
      set((state) => ({ businesses: state.businesses.filter(b => b._id !== id) }))
      return { success: true }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to delete' }
    }
  },

  // Post actions
  fetchPosts: async () => {
    try {
      const { data } = await api.get('/posts')
      set({ posts: data })
      return data
    } catch (error) {
      console.error('Fetch posts error:', error)
      return []
    }
  },

  createPost: async (postData) => {
    try {
      const { data } = await api.post('/posts', postData)
      set((state) => ({ posts: [data, ...state.posts] }))
      return { success: true, data }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to create post' }
    }
  },

  updatePost: async (id, updates) => {
    try {
      const { data } = await api.put(`/posts/${id}`, updates)
      set((state) => ({
        posts: state.posts.map(p => p._id === id ? data : p)
      }))
      return { success: true, data }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to update' }
    }
  },

  deletePost: async (id) => {
    try {
      await api.delete(`/posts/${id}`)
      set((state) => ({ posts: state.posts.filter(p => p._id !== id) }))
      return { success: true }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to delete' }
    }
  },

  // Stats
  fetchStats: async () => {
    try {
      const { data } = await api.get('/user/stats')
      set({ stats: data })
      return data
    } catch (error) {
      console.error('Fetch stats error:', error)
      return null
    }
  },

  // Delete account
  deleteAccount: async () => {
    try {
      await api.delete('/user/account')
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      set({ user: null, token: null, businesses: [], posts: [], stats: null })
      return { success: true }
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Failed to delete account' }
    }
  }
}))

export default api
