import React from 'react'
import { useAuthStore } from '../store/authStore'
import { useStats } from '../hooks/useApi'
import { User, Shield, Trash2, ExternalLink, AlertTriangle } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Settings() {
  const { user, logout } = useAuthStore()
  const { data: stats } = useStats()

  const handleDeleteAccount = async () => {
    if (!confirm('WARNING: This will permanently delete your account and ALL data. Continue?')) return
    if (!confirm('FINAL WARNING: This cannot be undone. Are you sure?')) return

    try {
      const token = useAuthStore.getState().token
      const response = await fetch('/api/users/account', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      })

      if (response.ok) {
        logout()
        toast.success('Account deleted successfully')
      } else {
        throw new Error('Failed to delete account')
      }
    } catch (err) {
      toast.error(err.message)
    }
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">Manage your account and preferences</p>
      </div>

      <div className="max-w-2xl space-y-6">
        {/* Account Info */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <User size={20} /> Account Information
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
              <input
                type="text"
                value={user?.name || ''}
                readOnly
                className="input bg-gray-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                value={user?.email || ''}
                readOnly
                className="input bg-gray-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Account Type</label>
              <input
                type="text"
                value={user?.googleId ? 'Google Account' : 'Email Account'}
                readOnly
                className="input bg-gray-50"
              />
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Shield size={20} /> Data Overview
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Total Posts</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.totalPosts || 0}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Businesses</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.totalBusinesses || 0}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Scheduled</p>
              <p className="text-2xl font-bold text-blue-600">{stats?.scheduledPosts || 0}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Published</p>
              <p className="text-2xl font-bold text-green-600">{stats?.publishedPosts || 0}</p>
            </div>
          </div>
        </div>

        {/* Google OAuth Setup */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <ExternalLink size={20} /> Google OAuth Setup
          </h3>
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4">
            <h4 className="font-semibold text-green-800 mb-2">To enable real Google Sign-In:</h4>
            <ol className="text-sm text-green-700 space-y-2 list-decimal list-inside">
              <li>Go to <a href="https://console.cloud.google.com" target="_blank" className="underline font-medium">Google Cloud Console</a></li>
              <li>Create a new project or select existing</li>
              <li>Enable <strong>Google Business Profile API</strong></li>
              <li>Go to <strong>APIs & Services {'>'} Credentials</strong></li>
              <li>Click <strong>Create Credentials {'>'} OAuth client ID</strong></li>
              <li>Select <strong>Web application</strong></li>
              <li>Add your domain to <strong>Authorized JavaScript origins</strong></li>
              <li>Add redirect URI: <code className="bg-white px-2 py-1 rounded text-xs">YOUR_DOMAIN/api/auth/google/callback</code></li>
              <li>Copy <strong>Client ID</strong> and <strong>Client Secret</strong></li>
              <li>Add them to your backend <code className="bg-white px-2 py-1 rounded text-xs">.env</code> file</li>
            </ol>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-sm text-blue-700">
              <strong>Note:</strong> Google Business Profile API requires verification. 
              Apply for access at <a href="https://developers.google.com/my-business/content/prereqs" target="_blank" className="underline">Google Business Profile API Prerequisites</a>
            </p>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="card p-6 border-red-200">
          <h3 className="text-lg font-semibold text-red-600 mb-4 flex items-center gap-2">
            <AlertTriangle size={20} /> Danger Zone
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Delete your account and all associated data permanently. This action cannot be undone.
          </p>
          <button
            onClick={handleDeleteAccount}
            className="btn-danger"
          >
            <Trash2 size={18} /> Delete My Account
          </button>
        </div>
      </div>
    </div>
  )
}
