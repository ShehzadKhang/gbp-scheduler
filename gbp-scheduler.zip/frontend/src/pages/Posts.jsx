import React, { useState } from 'react'
import { usePosts, useCreatePost, useDeletePost } from '../hooks/useApi'
import { useBusinesses } from '../hooks/useApi'
import { CalendarDays, Plus, Trash2, Copy, Clock, CheckCircle2, PenTool, Image as ImageIcon, X } from 'lucide-react'
import toast from 'react-hot-toast'

const CTA_OPTIONS = [
  { value: 'NONE', label: 'None' },
  { value: 'BOOK', label: 'Book' },
  { value: 'ORDER', label: 'Order' },
  { value: 'BUY', label: 'Buy' },
  { value: 'LEARN_MORE', label: 'Learn More' },
  { value: 'CALL', label: 'Call' },
  { value: 'SIGN_UP', label: 'Sign Up' },
  { value: 'GET_OFFER', label: 'Get Offer' }
]

const POST_TYPES = [
  { value: 'STANDARD', label: 'Standard' },
  { value: 'OFFER', label: 'Offer' },
  { value: 'EVENT', label: 'Event' },
  { value: 'PRODUCT', label: 'Product' }
]

export default function Posts() {
  const { data: posts, isLoading } = usePosts()
  const { data: businesses } = useBusinesses()
  const createPost = useCreatePost()
  const deletePost = useDeletePost()
  const [showModal, setShowModal] = useState(false)
  const [imagePreview, setImagePreview] = useState(null)
  const [formData, setFormData] = useState({
    businessId: '',
    content: '',
    image: null,
    ctaType: 'NONE',
    ctaUrl: '',
    postType: 'STANDARD',
    scheduleDate: '',
    scheduleTime: ''
  })

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be less than 5MB')
      return
    }
    const reader = new FileReader()
    reader.onload = (e) => {
      setImagePreview(e.target.result)
      setFormData({...formData, image: e.target.result})
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e, status) => {
    e.preventDefault()

    if (!formData.businessId) {
      toast.error('Please select a business')
      return
    }
    if (!formData.content.trim()) {
      toast.error('Please enter post content')
      return
    }

    let scheduledAt = null
    if (status === 'scheduled') {
      if (!formData.scheduleDate || !formData.scheduleTime) {
        toast.error('Please select date and time')
        return
      }
      scheduledAt = new Date(`${formData.scheduleDate}T${formData.scheduleTime}`).toISOString()
      if (new Date(scheduledAt) <= new Date()) {
        toast.error('Schedule time must be in the future')
        return
      }
    }

    const data = {
      businessId: formData.businessId,
      content: formData.content,
      image: formData.image,
      ctaType: formData.ctaType,
      ctaUrl: formData.ctaType !== 'NONE' ? formData.ctaUrl : null,
      postType: formData.postType,
      status,
      scheduledAt
    }

    try {
      await createPost.mutateAsync(data)
      toast.success(status === 'draft' ? 'Draft saved!' : 'Post scheduled!')
      setShowModal(false)
      resetForm()
    } catch (err) {
      toast.error(err.message)
    }
  }

  const resetForm = () => {
    setFormData({
      businessId: '',
      content: '',
      image: null,
      ctaType: 'NONE',
      ctaUrl: '',
      postType: 'STANDARD',
      scheduleDate: '',
      scheduleTime: ''
    })
    setImagePreview(null)
  }

  const handleDelete = async (id) => {
    if (!confirm('Delete this post?')) return
    try {
      await deletePost.mutateAsync(id)
      toast.success('Post deleted')
    } catch (err) {
      toast.error(err.message)
    }
  }

  const getStatusBadge = (status) => {
    const configs = {
      draft: { icon: PenTool, class: 'bg-amber-50 text-amber-700', label: 'Draft' },
      scheduled: { icon: Clock, class: 'bg-blue-50 text-blue-700', label: 'Scheduled' },
      published: { icon: CheckCircle2, class: 'bg-green-50 text-green-700', label: 'Published' },
      failed: { icon: X, class: 'bg-red-50 text-red-700', label: 'Failed' }
    }
    const config = configs[status] || configs.draft
    const Icon = config.icon
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${config.class}`}>
        <Icon size={12} /> {config.label}
      </span>
    )
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">All Posts</h1>
          <p className="text-gray-500 mt-1">Manage and track your GBP posts</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          <Plus size={18} /> Create Post
        </button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3].map(i => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-40 bg-gray-200 rounded-xl mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      ) : posts?.length === 0 ? (
        <div className="card p-12 text-center">
          <CalendarDays size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts yet</h3>
          <p className="text-gray-500 mb-6">Create your first post to get started</p>
          <button 
            onClick={() => setShowModal(true)}
            className="btn-primary"
          >
            <Plus size={18} /> Create First Post
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {posts.map((post) => (
            <div key={post._id} className="card overflow-hidden hover:shadow-md transition-shadow">
              {post.image ? (
                <img src={post.image} alt="Post" className="w-full h-40 object-cover" />
              ) : (
                <div className="w-full h-40 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                  <ImageIcon size={48} className="text-white/50" />
                </div>
              )}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-primary">
                    {post.business?.name || 'Unknown'}
                  </span>
                  {getStatusBadge(post.status)}
                </div>
                <p className="text-sm text-gray-700 line-clamp-3 mb-3">{post.content}</p>
                {post.ctaType !== 'NONE' && (
                  <span className="inline-block px-3 py-1 bg-primary-light text-primary text-xs font-semibold rounded-full mb-3">
                    {CTA_OPTIONS.find(c => c.value === post.ctaType)?.label}
                  </span>
                )}
                {post.scheduledAt && (
                  <p className="text-xs text-gray-500 flex items-center gap-1 mb-3">
                    <Clock size={12} />
                    {new Date(post.scheduledAt).toLocaleString()}
                  </p>
                )}
                <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                  <button
                    onClick={() => handleDelete(post._id)}
                    className="p-2 text-gray-400 hover:text-danger hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Post Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-lg font-bold">Create New Post</h2>
              <button 
                onClick={() => { setShowModal(false); resetForm() }}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X size={20} />
              </button>
            </div>

            <form className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Business *</label>
                <select
                  value={formData.businessId}
                  onChange={(e) => setFormData({...formData, businessId: e.target.value})}
                  className="input"
                  required
                >
                  <option value="">Select a business...</option>
                  {businesses?.map(b => (
                    <option key={b._id} value={b._id}>{b.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Content *</label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({...formData, content: e.target.value})}
                  className="input min-h-[120px] resize-y"
                  placeholder="What's new with your business?"
                  maxLength={1500}
                  required
                />
                <p className="text-xs text-gray-400 mt-1 text-right">{formData.content.length}/1500</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Photo</label>
                <div 
                  onClick={() => document.getElementById('postImage').click()}
                  className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:border-primary hover:bg-primary-light/20 transition-all"
                >
                  {imagePreview ? (
                    <div className="relative">
                      <img src={imagePreview} alt="Preview" className="max-h-40 mx-auto rounded-lg" />
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setImagePreview(null); setFormData({...formData, image: null}) }}
                        className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-black/70"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <ImageIcon size={32} className="mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">Click to upload image</p>
                      <p className="text-xs text-gray-400">JPG/PNG, max 5MB</p>
                    </>
                  )}
                </div>
                <input
                  type="file"
                  id="postImage"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Call to Action</label>
                <div className="grid grid-cols-4 gap-2">
                  {CTA_OPTIONS.map((cta) => (
                    <button
                      key={cta.value}
                      type="button"
                      onClick={() => setFormData({...formData, ctaType: cta.value})}
                      className={`px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                        formData.ctaType === cta.value
                          ? 'border-primary bg-primary-light text-primary'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      {cta.label}
                    </button>
                  ))}
                </div>
              </div>

              {formData.ctaType !== 'NONE' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Button URL *</label>
                  <input
                    type="url"
                    value={formData.ctaUrl}
                    onChange={(e) => setFormData({...formData, ctaUrl: e.target.value})}
                    className="input"
                    placeholder="https://your-website.com"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Schedule For</label>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="date"
                    value={formData.scheduleDate}
                    onChange={(e) => setFormData({...formData, scheduleDate: e.target.value})}
                    className="input"
                  />
                  <input
                    type="time"
                    value={formData.scheduleTime}
                    onChange={(e) => setFormData({...formData, scheduleTime: e.target.value})}
                    className="input"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Leave empty to save as draft. Set future time to schedule auto-publish.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Post Type</label>
                <select
                  value={formData.postType}
                  onChange={(e) => setFormData({...formData, postType: e.target.value})}
                  className="input"
                >
                  {POST_TYPES.map(type => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => { setShowModal(false); resetForm() }}
                  className="btn-outline flex-1"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={(e) => handleSubmit(e, 'draft')}
                  disabled={createPost.isLoading}
                  className="btn-outline flex-1 disabled:opacity-50"
                >
                  Save Draft
                </button>
                <button
                  type="button"
                  onClick={(e) => handleSubmit(e, 'scheduled')}
                  disabled={createPost.isLoading}
                  className="btn-primary flex-1 disabled:opacity-50"
                >
                  {createPost.isLoading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    'Schedule'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
