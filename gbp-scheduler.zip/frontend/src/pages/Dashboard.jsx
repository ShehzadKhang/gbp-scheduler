import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import { useStats } from '../hooks/useApi'
import { 
  Building2, 
  CalendarDays, 
  Clock, 
  CheckCircle2, 
  PenTool,
  Plus,
  ArrowRight
} from 'lucide-react'

const StatCard = ({ icon: Icon, label, value, color, onClick }) => (
  <div 
    onClick={onClick}
    className="card p-6 hover:shadow-md transition-shadow cursor-pointer"
  >
    <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center mb-4`}>
      <Icon size={24} className="text-white" />
    </div>
    <p className="text-sm text-gray-500 mb-1">{label}</p>
    <p className="text-3xl font-bold text-gray-900">{value}</p>
  </div>
)

export default function Dashboard() {
  const { user } = useAuthStore()
  const navigate = useNavigate()
  const { data: stats, isLoading } = useStats()

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Welcome back, {user?.name}</p>
        </div>
        <button 
          onClick={() => navigate('/posts')}
          className="btn-primary"
        >
          <Plus size={18} /> Create Post
        </button>
      </div>

      {/* Stats Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[1,2,3,4].map(i => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="w-12 h-12 bg-gray-200 rounded-xl mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-20 mb-2"></div>
              <div className="h-8 bg-gray-200 rounded w-12"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={Building2}
            label="My Businesses"
            value={stats?.totalBusinesses || 0}
            color="bg-gradient-to-br from-primary to-primary-dark"
            onClick={() => navigate('/businesses')}
          />
          <StatCard
            icon={Clock}
            label="Scheduled"
            value={stats?.scheduledPosts || 0}
            color="bg-gradient-to-br from-amber-500 to-orange-600"
            onClick={() => navigate('/scheduled')}
          />
          <StatCard
            icon={CheckCircle2}
            label="Published"
            value={stats?.publishedPosts || 0}
            color="bg-gradient-to-br from-success to-emerald-700"
            onClick={() => navigate('/published')}
          />
          <StatCard
            icon={PenTool}
            label="Drafts"
            value={stats?.draftPosts || 0}
            color="bg-gradient-to-br from-purple-500 to-purple-700"
            onClick={() => navigate('/posts')}
          />
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button 
              onClick={() => navigate('/businesses')}
              className="w-full flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-primary-light hover:text-primary transition-colors text-left"
            >
              <div className="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center">
                <Building2 size={20} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Add Business Profile</p>
                <p className="text-sm text-gray-500">Connect your Google Business Profile</p>
              </div>
              <ArrowRight size={18} className="text-gray-400" />
            </button>

            <button 
              onClick={() => navigate('/posts')}
              className="w-full flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-primary-light hover:text-primary transition-colors text-left"
            >
              <div className="w-10 h-10 bg-white rounded-lg shadow-sm flex items-center justify-center">
                <CalendarDays size={20} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Create New Post</p>
                <p className="text-sm text-gray-500">Schedule a post for your business</p>
              </div>
              <ArrowRight size={18} className="text-gray-400" />
            </button>
          </div>
        </div>

        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Getting Started</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary-light text-primary flex items-center justify-center text-sm font-bold shrink-0">1</div>
              <div>
                <p className="font-medium text-gray-900">Add Your Business</p>
                <p className="text-sm text-gray-500">Connect your Google Business Profile to get started</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary-light text-primary flex items-center justify-center text-sm font-bold shrink-0">2</div>
              <div>
                <p className="font-medium text-gray-900">Create a Post</p>
                <p className="text-sm text-gray-500">Write content, add images, and set a call-to-action</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary-light text-primary flex items-center justify-center text-sm font-bold shrink-0">3</div>
              <div>
                <p className="font-medium text-gray-900">Schedule & Publish</p>
                <p className="text-sm text-gray-500">Pick a date and time, and we'll auto-publish for you</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
