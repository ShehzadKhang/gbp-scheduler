import React from 'react'
import { usePosts } from '../hooks/useApi'
import { Clock, CalendarDays } from 'lucide-react'

export default function Scheduled() {
  const { data: posts, isLoading } = usePosts('scheduled')

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Scheduled Posts</h1>
        <p className="text-gray-500 mt-1">Posts waiting to be published</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2].map(i => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      ) : posts?.length === 0 ? (
        <div className="card p-12 text-center">
          <Clock size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No scheduled posts</h3>
          <p className="text-gray-500">Create a post and schedule it for the future</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <div key={post._id} className="card p-6 flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 shrink-0">
                <Clock size={24} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className="font-semibold text-gray-900">{post.business?.name}</span>
                  <span className="px-2 py-1 bg-blue-50 text-blue-700 text-xs font-semibold rounded-full">
                    Scheduled
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-2">{post.content}</p>
                <p className="text-sm text-blue-600 flex items-center gap-2">
                  <CalendarDays size={14} />
                  Publishing: {new Date(post.scheduledAt).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
