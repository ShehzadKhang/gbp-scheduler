import React, { useState } from 'react'
import { useBusinesses, useCreateBusiness, useDeleteBusiness } from '../hooks/useApi'
import { Building2, Plus, Trash2, MapPin, Phone, Globe, Tag } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Businesses() {
  const { data: businesses, isLoading } = useBusinesses()
  const createBusiness = useCreateBusiness()
  const deleteBusiness = useDeleteBusiness()
  const [showModal, setShowModal] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    website: '',
    category: ''
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.name.trim()) {
      toast.error('Business name is required')
      return
    }

    try {
      await createBusiness.mutateAsync(formData)
      toast.success('Business added successfully!')
      setShowModal(false)
      setFormData({ name: '', address: '', phone: '', website: '', category: '' })
    } catch (err) {
      toast.error(err.message)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to remove this business?')) return
    try {
      await deleteBusiness.mutateAsync(id)
      toast.success('Business removed')
    } catch (err) {
      toast.error(err.message)
    }
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Business Profiles</h1>
          <p className="text-gray-500 mt-1">Manage your Google Business Profile connections</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          <Plus size={18} /> Add Business
        </button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1,2].map(i => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-200 rounded-xl"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : businesses?.length === 0 ? (
        <div className="card p-12 text-center">
          <Building2 size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No businesses yet</h3>
          <p className="text-gray-500 mb-6">Add your first Google Business Profile to start scheduling posts</p>
          <button 
            onClick={() => setShowModal(true)}
            className="btn-primary"
          >
            <Plus size={18} /> Add First Business
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {businesses.map((business) => (
            <div key={business._id} className="card p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-dark rounded-xl flex items-center justify-center text-white shrink-0">
                  <Building2 size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 truncate">{business.name}</h3>
                  <div className="space-y-1 mt-2">
                    {business.address && (
                      <p className="text-sm text-gray-500 flex items-center gap-2">
                        <MapPin size={14} /> {business.address}
                      </p>
                    )}
                    {business.phone && (
                      <p className="text-sm text-gray-500 flex items-center gap-2">
                        <Phone size={14} /> {business.phone}
                      </p>
                    )}
                    {business.website && (
                      <p className="text-sm text-gray-500 flex items-center gap-2">
                        <Globe size={14} /> {business.website}
                      </p>
                    )}
                    {business.category && (
                      <p className="text-sm text-gray-500 flex items-center gap-2">
                        <Tag size={14} /> {business.category}
                      </p>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(business._id)}
                  className="p-2 text-gray-400 hover:text-danger hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}

          <button 
            onClick={() => setShowModal(true)}
            className="card p-6 border-2 border-dashed border-gray-300 hover:border-primary hover:bg-primary-light/30 transition-all text-center"
          >
            <Plus size={32} className="mx-auto text-gray-400 mb-2" />
            <p className="font-medium text-gray-600">Add Another Business</p>
          </button>
        </div>
      )}

      {/* Add Business Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-lg font-bold">Add Business Profile</h2>
              <button 
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Business Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="input"
                  placeholder="Your Business Name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  className="input"
                  placeholder="123 Main St, City, State"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="input"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                <input
                  type="url"
                  value={formData.website}
                  onChange={(e) => setFormData({...formData, website: e.target.value})}
                  className="input"
                  placeholder="https://yourbusiness.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="input"
                  placeholder="Restaurant, Retail, Service..."
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn-outline flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createBusiness.isLoading}
                  className="btn-primary flex-1 disabled:opacity-50"
                >
                  {createBusiness.isLoading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Plus size={18} /> Add Business
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
