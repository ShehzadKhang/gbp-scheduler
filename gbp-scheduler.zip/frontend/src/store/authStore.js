import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      setToken: (token) => {
        set({ token, isAuthenticated: true })
        get().fetchUser()
      },

      setUser: (user) => set({ user }),

      fetchUser: async () => {
        const token = get().token
        if (!token) return

        try {
          const response = await fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${token}` }
          })

          if (response.ok) {
            const data = await response.json()
            set({ user: data.user })
          } else {
            get().logout()
          }
        } catch (err) {
          console.error('Fetch user error:', err)
        }
      },

      logout: () => {
        set({ user: null, token: null, isAuthenticated: false })
        localStorage.removeItem('auth-storage')
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ token: state.token, isAuthenticated: state.isAuthenticated })
    }
  )
)
