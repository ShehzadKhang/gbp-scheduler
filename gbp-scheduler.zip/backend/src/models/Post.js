const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  business: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Business',
    required: true
  },
  content: {
    type: String,
    required: true,
    maxlength: 1500
  },
  image: {
    type: String,
    default: null
  },
  ctaType: {
    type: String,
    enum: ['NONE', 'BOOK', 'ORDER', 'BUY', 'LEARN_MORE', 'CALL', 'SIGN_UP', 'GET_OFFER'],
    default: 'NONE'
  },
  ctaUrl: {
    type: String,
    default: null
  },
  postType: {
    type: String,
    enum: ['STANDARD', 'OFFER', 'EVENT', 'PRODUCT'],
    default: 'STANDARD'
  },
  status: {
    type: String,
    enum: ['draft', 'scheduled', 'published', 'failed'],
    default: 'draft'
  },
  scheduledAt: {
    type: Date,
    default: null
  },
  publishedAt: {
    type: Date,
    default: null
  },
  googlePostId: {
    type: String,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Post', postSchema);
