const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Business = require('../models/Business');

// Get all businesses for current user
router.get('/', auth, async (req, res) => {
  try {
    const businesses = await Business.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json(businesses);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create business
router.post('/', auth, async (req, res) => {
  try {
    const { name, address, phone, website, category } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Business name is required' });
    }

    const business = new Business({
      user: req.user._id,
      name,
      address: address || '',
      phone: phone || '',
      website: website || '',
      category: category || ''
    });

    await business.save();
    res.status(201).json(business);
  } catch (err) {
    console.error('Create business error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update business
router.put('/:id', auth, async (req, res) => {
  try {
    const business = await Business.findOne({ _id: req.params.id, user: req.user._id });
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    const updates = req.body;
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) business[key] = updates[key];
    });

    await business.save();
    res.json(business);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete business
router.delete('/:id', auth, async (req, res) => {
  try {
    const business = await Business.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }
    res.json({ message: 'Business deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
