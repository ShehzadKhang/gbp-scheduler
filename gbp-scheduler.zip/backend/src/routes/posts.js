const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Post = require('../models/Post');
const Business = require('../models/Business');

// Get all posts for current user
router.get('/', auth, async (req, res) => {
  try {
    const { status } = req.query;
    const query = { user: req.user._id };
    if (status) query.status = status;

    const posts = await Post.find(query)
      .populate('business', 'name address')
      .sort({ createdAt: -1 });

    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Create post
router.post('/', auth, async (req, res) => {
  try {
    const { businessId, content, image, ctaType, ctaUrl, postType, status, scheduledAt } = req.body;

    if (!businessId || !content) {
      return res.status(400).json({ error: 'Business and content are required' });
    }

    // Verify business belongs to user
    const business = await Business.findOne({ _id: businessId, user: req.user._id });
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    const post = new Post({
      user: req.user._id,
      business: businessId,
      content,
      image: image || null,
      ctaType: ctaType || 'NONE',
      ctaUrl: ctaUrl || null,
      postType: postType || 'STANDARD',
      status: status || 'draft',
      scheduledAt: scheduledAt ? new Date(scheduledAt) : null
    });

    await post.save();
    await post.populate('business');

    res.status(201).json(post);
  } catch (err) {
    console.error('Create post error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update post
router.put('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findOne({ _id: req.params.id, user: req.user._id });
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const updates = req.body;
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        if (key === 'scheduledAt') {
          post[key] = updates[key] ? new Date(updates[key]) : null;
        } else {
          post[key] = updates[key];
        }
      }
    });

    await post.save();
    await post.populate('business');
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete post
router.delete('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }
    res.json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
