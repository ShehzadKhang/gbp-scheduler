const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const Post = require('../models/Post');
const Business = require('../models/Business');

// Get user stats
router.get('/stats', auth, async (req, res) => {
  try {
    const totalPosts = await Post.countDocuments({ user: req.user._id });
    const scheduledPosts = await Post.countDocuments({ user: req.user._id, status: 'scheduled' });
    const publishedPosts = await Post.countDocuments({ user: req.user._id, status: 'published' });
    const draftPosts = await Post.countDocuments({ user: req.user._id, status: 'draft' });
    const totalBusinesses = await Business.countDocuments({ user: req.user._id });

    res.json({
      totalPosts,
      scheduledPosts,
      publishedPosts,
      draftPosts,
      totalBusinesses
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete account and all data
router.delete('/account', auth, async (req, res) => {
  try {
    await Post.deleteMany({ user: req.user._id });
    await Business.deleteMany({ user: req.user._id });
    await User.findByIdAndDelete(req.user._id);
    res.json({ message: 'Account and all data deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
