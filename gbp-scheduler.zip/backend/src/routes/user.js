const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const Post = require('../models/Post');
const Business = require('../models/Business');

// @route   GET /api/user/stats
// @desc    Get user dashboard stats
// @access  Private
router.get('/stats', auth, async (req, res) => {
  try {
    const totalPosts = await Post.countDocuments({ userId: req.user.id });
    const scheduledPosts = await Post.countDocuments({ userId: req.user.id, status: 'scheduled' });
    const publishedPosts = await Post.countDocuments({ userId: req.user.id, status: 'published' });
    const draftPosts = await Post.countDocuments({ userId: req.user.id, status: 'draft' });
    const totalBusinesses = await Business.countDocuments({ userId: req.user.id });

    res.json({
      totalPosts,
      scheduledPosts,
      publishedPosts,
      draftPosts,
      totalBusinesses
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/user/account
// @desc    Delete user account and all data
// @access  Private
router.delete('/account', auth, async (req, res) => {
  try {
    await Post.deleteMany({ userId: req.user.id });
    await Business.deleteMany({ userId: req.user.id });
    await User.findByIdAndDelete(req.user.id);

    res.json({ message: 'Account and all data deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;